#include <dolfin.h>
using namespace dolfin;

void compute_entropy_viscosity(Mesh& mesh, Function& res, Function& u, Function& mu);
